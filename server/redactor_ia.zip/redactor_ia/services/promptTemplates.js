// server/redactor_ia/services/promptTemplates.js
/**
 * Plantillas de prompt neutrales por tema
 * SIN sesgos, SIN forzados de clima/interior/exterior
 * Solo restricción anti-texto del modelo
 */

/**
 * Regla anti-texto + anti-banderas MINIMALISTA
 * SIN banderas, SIN símbolos nacionales, SIN texto
 */
const NO_TEXT_RULE = 'text, letters, logos, watermarks, readable signage, flags, national symbols, emblems';

/**
 * Plantillas de prompt por contextId
 * Neutrales, ilustrativas, sin imposiciones de clima/ubicación
 */
const PROMPT_TEMPLATES = {
  justice: {
    positive: 'Editorial photo or concept illustration of rule of law — balanced scales abstracted, courthouse architectural elements (no logos), neutral professional lighting, realistic style, 3:2 aspect ratio.',
    negative: ''
  },
  
  politics: {
    positive: 'Press briefing concept: microphones abstracted, flag colors as abstract patterns (no emblems), newsroom depth of field, editorial realism, neutral backdrop, 3:2.',
    negative: ''
  },
  
  economy: {
    positive: 'Market and finance abstract concept: coins, graphs as geometric shapes, hands exchanging goods symbolically, realistic editorial mood, professional photography style, 3:2.',
    negative: ''
  },
  
  technology: {
    positive: 'Modern tech environment: lab or server racks abstracted, circuitry motifs, blue hour lighting, editorial realism, professional tech journalism style, 3:2.',
    negative: ''
  },
  
  sports: {
    positive: 'Sports concept: athletic motion abstracted, stadium atmosphere (no visible text), dynamic action, editorial sports photography style, 3:2.',
    negative: ''
  },
  
  culture: {
    positive: 'Cultural scene: artistic elements abstracted, exhibition or performance atmosphere (no readable text), artistic lighting, editorial cultural journalism, 3:2.',
    negative: ''
  },
  
  society: {
    positive: 'Community and civic life: people in public spaces (no close-up faces), urban or neighborhood setting, documentary social photography, neutral composition, 3:2.',
    negative: ''
  },
  
  disaster: {
    positive: 'Emergency response or weather impact scene: outdoor aftermath if applicable, rescue personnel in action (no graphic injuries), severe weather visible, photojournalism style, dramatic natural lighting, 3:2.',
    negative: ''
  },
  
  generic: {
    positive: 'Neutral editorial illustration related to the topic with subtle symbolism; professional photo/illustration blend; balanced composition; 3:2.',
    negative: ''
  }
};

/**
 * Mapa de hints visuales por país (ambiente neutro SIN banderas ni símbolos oficiales)
 */
const COUNTRY_VISUAL_HINTS = {
  'Cuba': 'ciudad caribeña con edificios bajos y coloridos, balcones antiguos y vegetación tropical',
  'Belgium': 'plaza europea con edificios históricos de ladrillo y clima templado',
  'United Kingdom': 'ciudad europea con edificios antiguos de piedra y clima nublado',
  'United States': 'ciudad moderna con rascacielos y amplias avenidas',
  'Russia': 'ciudad con arquitectura sóvida y clima frío',
  'India': 'ciudad asiática vibrante con calles concurridas y vegetación cálida',
  'China': 'ciudad asiática moderna con alta densidad urbana',
  'France': 'ciudad europea con arquitectura clásica y avenidas arboladas',
  'Germany': 'ciudad europea moderna con arquitectura funcional',
  'Spain': 'ciudad mediterránea con edificios de piedra y clima soleado',
  'Italy': 'ciudad mediterránea con arquitectura histórica',
  'Japan': 'ciudad asiática moderna con tecnología y orden urbano',
  'Mexico': 'ciudad latinoamericana con arquitectura colorida y clima cálido',
  'Brazil': 'ciudad latinoamericana tropical con edificios modernos',
  'Argentina': 'ciudad latinoamericana con arquitectura europea y avenidas amplias',
  'global': 'entorno urbano moderno genérico sin referencias culturales específicas'
};

/**
 * Construye hint visual de país (descripción de ambiente SIN mencionar el país)
 * @param {string} countryName - Nombre del país detectado (o 'global')
 * @returns {string} Descripción de ambiente neutral
 */
function buildCountryVisualHint(countryName) {
  const hint = COUNTRY_VISUAL_HINTS[countryName] || COUNTRY_VISUAL_HINTS['global'];
  return hint;
}

/**
 * Construye escena simbólica contextual combinando tipo de escena + ambiente de país
 * @param {string} visualSceneType - Tipo de escena (press_conference, political_protest, citizen_government_interaction, etc.)
 * @param {string} countryVisualHint - Descripción de ambiente del país
 * @returns {string} Texto de escena simbólica
 */
function buildSymbolicScene(visualSceneType, countryVisualHint) {
  const baseStyle = 'Ilustración editorial a todo color, estilo cómic/novela gráfica moderna.';
  const antiLikeness = 'Figuras humanas genéricas sin rasgos faciales definidos, sin parecido a personas reales ni a líderes políticos reconocibles. Máximo dos personajes principales en foco.';
  const restrictions = 'Sin texto en la imagen. Sin banderas, sin escudos, sin símbolos nacionales, sin logotipos.';
  
  switch (visualSceneType) {
    case 'press_conference':
      return `${baseStyle} Escena simbólica de rueda de prensa: un funcionario genérico hablando frente a periodistas y micrófonos en ${countryVisualHint}. ${antiLikeness} ${restrictions}`;
    
    case 'citizen_government_interaction':
      return `${baseStyle} Escena simbólica de encuentro tenso entre un funcionario y ciudadanos afectados: uno o dos representantes del gobierno frente a varias personas del pueblo en ${countryVisualHint}. ${antiLikeness} ${restrictions}`;
    
    case 'political_protest':
      return `${baseStyle} Escena simbólica de protesta ciudadana en ${countryVisualHint}: grupo de personas con carteles en blanco y gestos expresivos. ${antiLikeness} ${restrictions}`;
    
    case 'natural_disaster':
      return `${baseStyle} Escena simbólica de desastre natural en ${countryVisualHint}: viviendas y calles dañadas, personas ayudándose entre sí, equipos de apoyo genéricos. Sin uniformes ni símbolos oficiales. ${antiLikeness} ${restrictions}`;
    
    case 'economic_crisis':
      return `${baseStyle} Escena simbólica de crisis económica en un entorno urbano de ${countryVisualHint}: gráficas descendentes, monedas y billetes genéricos, personas preocupadas. ${antiLikeness} ${restrictions}`;
    
    case 'courtroom':
      return `${baseStyle} Escena simbólica de sala judicial en ${countryVisualHint}: juez genérico, abogados y acusado en tribunal formal. ${antiLikeness} ${restrictions}`;
    
    case 'military_tension':
      return `${baseStyle} Escena simbólica de tensión militar en ${countryVisualHint}: soldados genéricos, vehículos militares sin insignias, atmósfera tensa. ${antiLikeness} ${restrictions}`;
    
    case 'generic_scene':
    default:
      return `${baseStyle} Escena editorial neutra en ${countryVisualHint} relacionada con la noticia. ${antiLikeness} ${restrictions}`;
  }
}

/**
 * Construye prompt final basado en tema del engine + escena simbólica + país
 * NUEVA LÓGICA: Combina visualSceneType + countryVisualHint para imágenes contextuales seguras
 * @param {Object} theme - Resultado de ImageThemeEngine.deriveTheme() con visualSceneType
 * @param {Object} signals - { title, summary, content, tags, category, countryCode, countryName, entities, timeContext }
 * @returns {{ prompt: string, negative: string, locale: string, style: string, context: Object }}
 */
function buildPrompt(theme, signals) {
  const { contextId, disaster, keywords, visualSceneType = 'generic_scene' } = theme;
  const { 
    title = '', 
    summary = '', 
    category = '',
    tags = [],
    countryCode = null,
    countryName = 'global',
    entities = [],
    timeContext = null
  } = signals;
  
  // Seleccionar plantilla
  const template = PROMPT_TEMPLATES[contextId] || PROMPT_TEMPLATES.generic;
  
  // Keywords extendidas (top-5 en lugar de 3)
  const topKeywords = keywords.slice(0, 5).join(', ');
  
  // Etiquetas principales (máximo 5)
  const mainTags = Array.isArray(tags) ? tags.slice(0, 5).filter(t => t && t.trim()) : [];
  const tagsText = mainTags.length > 0 ? `Tags: ${mainTags.join(', ')}.` : '';
  
  // Categoría explícita
  const categoryText = category ? `Category: ${category}.` : '';
  
  // Construir ambiente de país neutral (SIN mencionar el país por nombre)
  const countryVisualHint = buildCountryVisualHint(countryName || 'global');
  
  // Construir escena simbólica contextual
  const symbolicSceneText = buildSymbolicScene(visualSceneType, countryVisualHint);
  
  // Contexto temporal si está disponible
  const timeText = timeContext ? `Time: ${timeContext}.` : '';
  
  // Entidades detectadas (personas, organizaciones, eventos)
  const entitiesText = Array.isArray(entities) && entities.length > 0 
    ? `Key entities: ${entities.slice(0, 3).join(', ')}.` 
    : '';
  
  // Construir prompt con escena simbólica al inicio
  let prompt = '';
  
  // Contexto base: título + resumen
  const baseContext = `${title}. ${summary}. ${categoryText} ${tagsText}`.trim();
  
  // Prompt = Contexto + Escena simbólica
  prompt = `${baseContext} ${symbolicSceneText}`.trim();
  
  // Estilo: cómic/novela gráfica editorial
  const style = 'comic_editorial';
  
  // Locale por defecto: español (Cuba)
  const locale = 'es-CU';
  
  // Negativos MÍNIMOS: solo anti-texto/logos (sin restricciones adicionales)
  const negative = NO_TEXT_RULE;
  
  // Limitar longitud del prompt
  if (prompt.length > 900) {
    prompt = prompt.substring(0, 900);
  }
  
  return { 
    prompt, 
    negative,
    locale,
    style,
    context: {
      category,
      tags: mainTags,
      countryCode,
      countryName,
      visualSceneType,
      entities: entities.slice(0, 3),
      keywords: keywords.slice(0, 5),
      contextId,
      disaster
    }
  };
}

module.exports = {
  buildPrompt,
  PROMPT_TEMPLATES,
  NO_TEXT_RULE
};
