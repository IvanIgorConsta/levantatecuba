// server/redactor_ia/utils/cubaFilters.js

/**
 * Filtros estrictos para contenido relacionado con Cuba
 * Usados cuando strictCuba mode está activo
 * Versión robusta: normaliza texto, incluye inglés, bypass por dominio
 */

/**
 * Normaliza texto eliminando diacríticos (acentos)
 * Ejemplo: "Camagüey" → "camaguey", "Díaz-Canel" → "diaz-canel"
 */
function removeDiacritics(str) {
  return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

// Palabras clave positivas (español + inglés)
// Array para permitir búsqueda con .includes() más flexible
const CUBA_POSITIVE_KEYWORDS = [
  // País y demonyms
  'cuba', 'cubano', 'cubana', 'cubanos', 'cubanas',
  // Capital
  'havana', 'la habana', 'habana',
  // Provincias y ciudades principales (15 provincias)
  'matanzas', 'pinar del rio', 'mayabeque', 'artemisa', 'isla de la juventud',
  'villa clara', 'cienfuegos', 'sancti spiritus', 'camaguey', 'las tunas',
  'holguin', 'granma', 'santiago de cuba', 'guantanamo', 'ciego de avila',
  // Gobierno y políticas
  'diaz canel', 'diaz-canel', 'dias canel', 'minrex', 'gaceta oficial',
  'fidel castro', 'raul castro',
  // Economía
  'bloqueo', 'embargo', 'remesas', 'mipyme', 'mipymes',
  'tarea ordenamiento', 'peso cubano', 'cup',
  'reforma economica cubana', 'economia cubana',
  // Social
  'disidencia cubana', 'derechos humanos cuba'
];

// Palabras de ruido global (aplicar solo si NO hay match positivo)
const NOISE_KEYWORDS = [
  'israel', 'gaza', 'ukraine', 'ucrania', 'russia', 'rusia',
  'nfl', 'nba', 'mlb', 'bitcoin', 'ethereum', 'grok'
];

// Hosts EXCLUIDOS de toda ingesta (blacklist dura)
const EXCLUDED_HOSTS = new Set([
  'cubadebate.cu'
]);

// Dominios cubanos con BYPASS TOTAL (medios 100% sobre Cuba)
// Estos medios publican casi exclusivamente sobre Cuba, no necesitan verificación de contenido
const HARD_CU_BYPASS = new Set([
  '14ymedio.com',
  'diariodecuba.com',
  'cibercuba.com',
  'cubanet.org',
  'martinoticias.com',
  'adncuba.com',
  'ddcuba.com',
  'cubanosporelmundo.com',
  'eltoque.com',        
  'eltoque.news',     
  'eltoque.org' 
]);

// Dominios cubanos MIXTOS que publican contenido regional/internacional
// REQUIEREN mención explícita de Cuba en el texto (NO bypass automático)
const CU_REQUIRE_POS = new Set([
  'prensa-latina.cu',
  'prensalatina.cu',
  'oncubamagazine.com',
  'radiohc.cu'
]);

// DEPRECADO: Movido a HARD_CU_BYPASS
const CUBA_SPECIALIZED = new Set([]);

/**
 * Concatena y normaliza texto de un artículo
 * @param {Object} article - { title, description, content }
 * @returns {string} Texto normalizado sin acentos en minúsculas
 */
function concatText(article) {
  if (!article) return '';
  const raw = `${article.title || ''} ${article.description || ''} ${article.content || ''}`;
  return removeDiacritics(raw.toLowerCase());
}

/**
 * Verifica si un artículo tiene match estricto con Cuba
 * @param {Object} article - { title, description, content }
 * @returns {boolean}
 */
function isCubaHardMatch(article) {
  if (!article) return false;
  
  const text = concatText(article);
  return CUBA_POSITIVE_KEYWORDS.some(keyword => text.includes(keyword));
}

/**
 * Verifica si un artículo es obviamente NO relacionado con Cuba
 * Detecta temas globales comunes que suelen ser ruido
 * IMPORTANTE: Solo aplica si NO hubo match positivo previo
 * @param {Object} article - { title, description }
 * @returns {boolean}
 */
function obviousNotCuba(article) {
  if (!article) return false;
  
  // Solo revisar título y descripción para ser más estricto
  const text = concatText({ title: article.title, description: article.description });
  
  // Si NO tiene match de Cuba Y contiene ruido → descartar
  if (isCubaHardMatch(article)) return false;
  
  return NOISE_KEYWORDS.some(noise => text.includes(noise));
}

/**
 * Verifica si un dominio tiene BYPASS TOTAL (medios 100% nacionales)
 * @param {string} host - hostname normalizado
 * @returns {boolean}
 */
function isCubaHostBypass(host) {
  if (!host) return false;
  const normalized = host.replace(/^www\./, '').toLowerCase();
  return HARD_CU_BYPASS.has(normalized);
}

/**
 * Verifica si un dominio es cubano pero requiere verificación de contenido
 * @param {string} host - hostname normalizado
 * @returns {boolean}
 */
function isCubaHostRequirePos(host) {
  if (!host) return false;
  const normalized = host.replace(/^www\./, '').toLowerCase();
  return CU_REQUIRE_POS.has(normalized) || CUBA_SPECIALIZED.has(normalized);
}

/**
 * Verifica si un artículo proviene de cualquier dominio cubano (bypass o require-pos)
 * @param {string} urlOrHost - URL completa o hostname
 * @returns {boolean}
 */
function isCubaDomain(urlOrHost) {
  if (!urlOrHost) return false;
  
  try {
    // Si es URL completa, extraer hostname
    let host = urlOrHost;
    if (urlOrHost.includes('://')) {
      host = new URL(urlOrHost).hostname;
    }
    
    // Normalizar (remover www.)
    host = host.replace(/^www\./, '').toLowerCase();
    
    return isCubaHostBypass(host) || isCubaHostRequirePos(host);
  } catch (error) {
    return false;
  }
}

/**
 * Verifica si las entidades extraídas contienen Cuba
 * Compatible con diferentes formatos de NER
 * @param {Array} entities - [{ text, type }] o similar
 * @returns {boolean}
 */
function hasCubaEntity(entities) {
  if (!entities || !Array.isArray(entities)) return false;
  
  return entities.some(entity => {
    const text = removeDiacritics((entity.text || entity.name || '').toLowerCase());
    const type = (entity.type || entity.label || '').toUpperCase();
    
    // Buscar "Cuba" o "Havana" en entidades de tipo GPE/LOC
    const hasCubaText = /cuba|havana/.test(text);
    const isLocationEntity = /GPE|LOC|LOCATION|PLACE/.test(type);
    
    return hasCubaText && isLocationEntity;
  });
}


/**
 * Filtra artículos en modo Cuba estricto (versión robusta)
 * Orden de evaluación:
 * 1. Bypass por dominio cubano → PASA
 * 2. Match positivo (texto o NER) → PASA
 * 3. Ruido obvio → RECHAZA
 * 4. Default conservador → RECHAZA
 * 
 * @param {Array} articles - Lista de artículos
 * @param {boolean} debug - Si true, loguea estadísticas detalladas
 * @returns {Array} Artículos filtrados
 */
function strictCubaFilter(articles, debug = false) {
  if (!Array.isArray(articles)) return [];
  
  const stats = {
    total: articles.length,
    passedByDomain: 0,
    passedByText: 0,
    passedByNER: 0,
    rejectedByNoise: 0,
    rejectedByDefault: 0
  };
  
  let excludedCount = 0;
  
  const filtered = articles.filter(article => {
    // Extraer hostname normalizado
    const hostname = article.hostname || (() => {
      try {
        const sourceUrl = article.url || article.sourceUrl || article.link;
        return sourceUrl ? new URL(sourceUrl).hostname.replace(/^www\./, '').toLowerCase() : '';
      } catch (e) {
        return (article.source?.name || '').toLowerCase();
      }
    })();
    
    // 0. EXCLUSIÓN DURA: Rechazar hosts en blacklist
    if (EXCLUDED_HOSTS.has(hostname)) {
      excludedCount++;
      return false;
    }
    
    // 1. BYPASS TOTAL: Medios 100% nacionales (Granma, JR, Trabajadores - SIN cubadebate)
    if (isCubaHostBypass(hostname)) {
      stats.passedByDomain++;
      return true;
    }
    
    // 2. Verificar contenido (para medios mixtos y resto)
    const hasTextMatch = isCubaHardMatch(article);
    const hasNERMatch = hasCubaEntity(article.entities);
    
    // Si es dominio cubano mixto (Prensa Latina, OnCuba, etc.), EXIGE mención de Cuba
    if (isCubaHostRequirePos(hostname)) {
      if (hasTextMatch || hasNERMatch) {
        if (hasTextMatch) stats.passedByText++;
        if (hasNERMatch) stats.passedByNER++;
        return true;
      } else {
        // Medio cubano pero sin mención de Cuba → rechazar (ej: Prensa Latina sobre Brasil)
        stats.rejectedByDefault++;
        return false;
      }
    }
    
    // 3. Para otros dominios, verificar contenido
    if (hasTextMatch || hasNERMatch) {
      if (hasTextMatch) stats.passedByText++;
      if (hasNERMatch) stats.passedByNER++;
      
      // Descartar si es ruido obvio
      if (obviousNotCuba(article)) {
        stats.rejectedByNoise++;
        return false;
      }
      
      return true;
    }
    
    // Sin match de Cuba, rechazar
    stats.rejectedByDefault++;
    return false;
  });
  
  // Log de estadísticas si debug está activo o si todos fueron rechazados
  if (debug || (filtered.length === 0 && stats.total > 0)) {
    console.info('[strictCubaFilter] Estadísticas:', {
      entrada: stats.total,
      salida: filtered.length,
      pasaron: {
        porDominio: stats.passedByDomain,
        porTexto: stats.passedByText,
        porNER: stats.passedByNER
      },
      rechazados: {
        porRuido: stats.rejectedByNoise,
        porDefecto: stats.rejectedByDefault,
        porExclusion: excludedCount
      }
    });
  }
  
  // Log de exclusiones si hubo
  if (excludedCount > 0) {
    console.info(`[strictCubaFilter] Excluidos por blacklist: ${excludedCount} artículos de:`, Array.from(EXCLUDED_HOSTS));
  }
  
  return filtered;
}

/**
 * Genera query para NewsAPI en modo Cuba estricto
 * Incluye variantes en español e inglés para máxima cobertura
 * @returns {string}
 */
function getCubaStrictQuery() {
  // Query simple sin paréntesis anidados (NewsAPI no los soporta bien)
  return 'Cuba OR cubano OR cubana OR Havana OR Cuban';
}


module.exports = {
  isCubaHardMatch,
  obviousNotCuba,
  hasCubaEntity,
  isCubaDomain,
  isCubaHostBypass,
  isCubaHostRequirePos,
  strictCubaFilter,
  getCubaStrictQuery,
  removeDiacritics,
  concatText,
  // Exportar para testing/debugging
  CUBA_POSITIVE_KEYWORDS,
  NOISE_KEYWORDS,
  HARD_CU_BYPASS,
  CU_REQUIRE_POS,
  CUBA_SPECIALIZED,
  EXCLUDED_HOSTS
};
