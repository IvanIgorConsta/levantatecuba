// server/redactor_ia/utils/sanitizeImagePrompt.js
/**
 * FALLBACK SANITIZER - Image Prompt Builder contextual v2
 * 
 * Este módulo actúa como FALLBACK cuando el builder contextual no está disponible.
 * Se invoca ÚNICAMENTE en los siguientes casos:
 * 1. opts.titleOnly === true (generación manual desde panel)
 * 2. buildImagePromptFromDraft() lanza excepción
 * 3. No hay datos suficientes en el draft (título/contenido vacío)
 * 4. imageProvider recibe prompt vacío o null
 * 
 * El flujo NORMAL usa buildImagePromptFromDraft() que construye prompts
 * basados en título + bajada + contenido + tags + categoría + país.
 * 
 * ESTRATEGIA EDITORIAL (fallback):
 * - Prompt simple basado solo en título
 * - Estilo cómic/novela gráfica editorial
 * - Sin caricaturas de personas reales específicas
 * - Sin filtros ni neutralización (la validación la hace OpenAI)
 */

/**
 * NO-OP: Retorna false siempre (sin detección de contenido sensible)
 * @deprecated - Solo para compatibilidad con código existente
 */
function hasSensitiveContent(text) {
  return false; // Desactivado
}

/**
 * NO-OP: Retorna false siempre (sin overlay de banderas)
 * @deprecated - Solo para compatibilidad con código existente
 */
function allowFlags(title, intent) {
  return false; // Desactivado
}

/**
 * NO-OP: Retorna 'generic' siempre (sin detección de intent)
 * @deprecated - Solo para compatibilidad con código existente
 */
function detectVisualIntentFromTitle(titleRaw = '') {
  return 'generic'; // Sin intent específico
}

/**
 * Genera prompt simple estilo cómic editorial
 * SIN filtrado, SIN neutralización, SIN lógica compleja
 * 
 * @param {Object} params
 * @param {string} params.title - Título de la noticia
 * @param {string} params.locale - Locale (es-CU, en-US, etc.)
 * @returns {string} Prompt simple y directo
 */
function sanitizeImagePrompt({ title, locale = 'es-CU' }) {
  const cleanTitle = String(title || '').trim();
  
  console.log(`[ImageSafety:Sanitizer] Prompt directo sin filtros propios: "${cleanTitle.substring(0, 80)}..."`);
  
  // Prompt simple estilo cómic editorial (SIN banderas ni símbolos nacionales)
  return `Ilustración editorial a todo color, estilo cómic / novela gráfica moderna. Personajes y escenario expresivos, con contornos marcados y colores vivos. Debe representar la escena y el contexto del titular, no un retrato literal de nadie. Puede mostrar personas y ambiente relacionados con la noticia, sin banderas ni símbolos nacionales. Sin elementos geopolíticos reconocibles. Evitar texto escrito dentro de la imagen. Titular: "${cleanTitle}".`;
}

/**
 * Prompt de fallback simbólico simple
 */
function getSymbolicFallbackPrompt(locale = 'es-CU') {
  return 'Ilustración editorial a todo color, estilo cómic / novela gráfica moderna. Escena periodística con personajes y ambiente expresivos, contornos marcados y colores vivos. Sin banderas ni símbolos nacionales.';
}

/**
 * Prompt de fallback genérico simple
 */
function getGenericFallbackPrompt(locale = 'es-CU') {
  return 'Ilustración editorial a todo color, estilo cómic / novela gráfica moderna. Escena editorial neutra con personajes y ambiente relacionados con la noticia. Sin texto en la imagen. Sin banderas ni símbolos nacionales.';
}

module.exports = {
  sanitizeImagePrompt,
  getSymbolicFallbackPrompt,
  getGenericFallbackPrompt,
  hasSensitiveContent,          // NO-OP (compatibilidad)
  detectVisualIntentFromTitle,  // NO-OP (compatibilidad)
  allowFlags                     // NO-OP (compatibilidad)
};
